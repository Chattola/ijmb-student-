# IJMB Student Hub

A mobile-first study companion for IJMB examination preparation — CBT practice quizzes,
study materials, a question bank, timetable/planner, progress tracking, bookmarks,
search, calculators, dark mode, and more. Built with plain HTML, CSS and JavaScript
(no framework, no build step, no paid backend). All data is stored locally in the
browser using `localStorage`.

## Project structure

```
ijmb-student-hub/
├── index.html          # App shell + loads css/js
├── css/
│   └── style.css       # All styling (design tokens, layout, components)
├── js/
│   ├── data.js          # Subjects, topics, study materials, SAMPLE questions, announcements
│   ├── storage.js       # Reusable localStorage read/write helpers
│   └── app.js            # Router + all views + quiz engine + calculators
└── assets/
    └── favicon.svg
```

## 1. Test it locally before deploying

You need a local web server (opening `index.html` directly with `file://` can block
some browser features). Pick whichever you have installed:

**Python (usually pre-installed on Mac/Linux):**
```bash
cd ijmb-student-hub
python3 -m http.server 8000
```
Then open **http://localhost:8000** in your browser.

**Node.js:**
```bash
cd ijmb-student-hub
npx serve .
```

**VS Code:** install the "Live Server" extension, right-click `index.html` →
"Open with Live Server".

Test on your phone too: on the same Wi-Fi network, find your computer's local IP
(e.g. `192.168.1.20`) and open `http://192.168.1.20:8000` on your Android phone.

## 2. Put the project on GitHub

1. Create a new repository on GitHub, e.g. `ijmb-student-hub` (no README/license needed,
   you already have this one).
2. From inside the `ijmb-student-hub` folder on your computer:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: IJMB Student Hub"
   git branch -M main
   git remote add origin https://github.com/<your-username>/ijmb-student-hub.git
   git push -u origin main
   ```

## 3. Enable GitHub Pages

1. On GitHub, open your repository → **Settings** → **Pages** (left sidebar).
2. Under **Build and deployment → Source**, choose **Deploy from a branch**.
3. Under **Branch**, choose `main` and folder `/ (root)`, then **Save**.
4. Wait 1–2 minutes. GitHub will show a green banner with your live URL, typically:
   `https://<your-username>.github.io/ijmb-student-hub/`
5. Open that link on your Android phone — you can even add it to your home screen
   (browser menu → "Add to Home screen") so it opens like an app.

No PHP, Node server, or paid hosting is required — everything runs in the browser.

## 4. Adding more content later

- **More subjects/topics:** add an object to the `SUBJECTS` array in `js/data.js`.
- **More study materials:** add an object to `MATERIALS` in `js/data.js`, matching an
  existing `subjectId`/`topicId`.
- **More questions:** add an object to `QUESTIONS` in `js/data.js`. Mark real,
  official content differently — everything currently shipped is clearly labelled
  `sample: true` and is demo content, not official IJMB past questions.
- **Announcements:** edit the `ANNOUNCEMENTS` array in `js/data.js`, or later swap it
  for a `fetch()` call to a real API — the rest of the app (`viewAnnouncements()` in
  `js/app.js`) doesn't need to change.

## 5. Upgrading to a real backend later

The app is intentionally structured so a backend can be added without a rewrite:

- All reads/writes already go through the functions in `js/storage.js`
  (`loadData`, `saveData`). Swap their internals for `fetch()` calls to your API and
  every view keeps working unchanged.
- `js/data.js` holds the current "content" (subjects, materials, questions,
  announcements) as static arrays — replace it with API calls that populate the same
  variable names (`SUBJECTS`, `MATERIALS`, `QUESTIONS`, `ANNOUNCEMENTS`).
- Add student accounts by extending the profile object in `STORE_KEYS.PROFILE` with
  an auth token, and gate `saveData`/`loadData` on being signed in.
- An admin dashboard, PDF uploads, sync between devices and subscriptions can all be
  layered on top of the same `SUBJECTS`/`MATERIALS`/`QUESTIONS` shapes already used
  throughout the UI.

## 6. Feature checklist & how to test each one

| # | Feature | How to test |
|---|---|---|
| 1 | Dashboard | Open the app — see welcome message, stats, subjects, quick actions, recent activity |
| 2 | Profile | Go to *More → Profile*, fill in your details, Save, refresh the page — details persist |
| 3 | Subjects (Biology/Chemistry/Physics) | Go to *Subjects* — 3 subjects, each with 4 topics |
| 4 | Study materials | Open a topic → see materials with explanation, key points, key terms, revision notes |
| 5 | CBT / practice quiz | *Quiz* tab → pick subject/topic/count → Start Quiz → answer, use Next/Previous/question grid → Submit → see result + review |
| 6 | Countdown timer | During a quiz, watch the timer count down; turns red under 30s; wait it out (or set a short quiz) to see auto-submit |
| 7 | Resume protection | Start a quiz, answer a question, refresh the browser tab, go to *Quiz* — a "Resume" banner appears |
| 8 | Question bank + filters | *More → Question Bank* → filter by subject/topic/difficulty, expand "Show explanation" |
| 9 | Score tracker + chart | Complete 2–3 quizzes → *More → Score Tracker* — see the bar chart and full history |
| 10 | Study timetable | *Planner* tab → **+ Add** → fill date/time/notes → Save → mark **Done** or **Delete** |
| 11 | Progress page | *More → Progress* — overall ring + per-subject progress bars update as you answer questions |
| 12 | Bookmarks | Bookmark a question (Question Bank) and a material (any material page) → *More → Bookmarks* → switch tabs, remove one |
| 13 | Global search | Tap the 🔍 icon in the top bar → type e.g. "cell" or "Ohm" → tap a result |
| 14 | Announcements | Tap the 🔔 icon → see reminders/exam/study announcements |
| 15 | Calculators | *More → Calculators* → try Basic (e.g. `12+8×2=`), Percentage, and Score/Grade tabs |
| 16 | Dark mode | Toggle 🌙/☀️ in the top bar, or the switch in *More → Settings* — refresh, preference is remembered |
| 17 | Mobile layout | Resize your browser narrow, or open on a phone — bottom nav appears, nothing scrolls sideways |
| 18 | Desktop layout | Widen the browser past ~900px — a left sidebar replaces the bottom nav |
| 19 | Error handling | Try saving a profile with no name, submitting a session with no date, an invalid calculator expression, an empty search, filtering questions to a combination with 0 results — the app shows a message instead of crashing |
| 20 | Data reset tools | *More → Settings* → "Clear quiz history" or "Reset all app data" |

Everything is stored only in your browser's `localStorage` on the device you're using —
clearing your browser data will also clear the app's saved data.
