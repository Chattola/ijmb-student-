/* ============================================================
   IJMB STUDENT HUB — data.js
   Static "seed" content: subjects, topics, study materials and
   a sample question bank. Everything here is DEMO / SAMPLE
   content written for this app — none of it is official IJMB
   past-question material. Add more subjects/topics/questions by
   extending the arrays below; no other file needs to change.
   ============================================================ */

/* ---------- SUBJECTS ---------------------------------------
   Add a new subject by pushing another object here with a
   unique id. Everything else (materials, questions) links back
   to a subject via subjectId + topicId.
---------------------------------------------------------------*/
const SUBJECTS = [
  {
    id: "biology",
    name: "Biology",
    icon: "🧬",
    color: "#2E9E6D",
    topics: [
      { id: "cell-structure", name: "Cell Structure & Organisation" },
      { id: "genetics", name: "Genetics & Heredity" },
      { id: "ecology", name: "Ecology & Environment" },
      { id: "photosynthesis", name: "Photosynthesis & Respiration" },
    ],
  },
  {
    id: "chemistry",
    name: "Chemistry",
    icon: "⚗️",
    color: "#2B3A67",
    topics: [
      { id: "atomic-structure", name: "Atomic Structure & Bonding" },
      { id: "periodic-table", name: "The Periodic Table" },
      { id: "acids-bases", name: "Acids, Bases & Salts" },
      { id: "organic-chem", name: "Introduction to Organic Chemistry" },
    ],
  },
  {
    id: "physics",
    name: "Physics",
    icon: "🧲",
    color: "#E4572E",
    topics: [
      { id: "mechanics", name: "Mechanics & Motion" },
      { id: "electricity", name: "Current Electricity" },
      { id: "waves", name: "Waves & Optics" },
      { id: "thermo", name: "Heat & Thermodynamics" },
    ],
  },
];

/* ---------- STUDY MATERIALS ---------------------------------
   subjectId + topicId must match an entry in SUBJECTS above.
   "sample" is always true for seed content shipped with the app.
---------------------------------------------------------------*/
const MATERIALS = [
  {
    id: "mat-bio-1",
    subjectId: "biology",
    topicId: "cell-structure",
    title: "The Animal & Plant Cell",
    sample: true,
    explanation:
      "A cell is the basic structural and functional unit of life. Animal and plant cells share organelles such as the nucleus, mitochondria and ribosomes, but plant cells additionally have a cell wall, chloroplasts and a large permanent vacuole, which animal cells lack.",
    keyPoints: [
      "The nucleus controls cell activities and holds genetic material (DNA).",
      "Mitochondria are the site of aerobic respiration — the 'powerhouse' of the cell.",
      "The cell wall (plants only) is made of cellulose and gives shape/support.",
      "Chloroplasts (plants only) contain chlorophyll and carry out photosynthesis.",
      "The cell membrane controls what substances enter and leave the cell.",
    ],
    keyTerms: [
      { term: "Organelle", def: "A specialised structure inside a cell that performs a specific job." },
      { term: "Cytoplasm", def: "The jelly-like substance filling the cell where chemical reactions occur." },
      { term: "Selective permeability", def: "The property of a membrane allowing only certain substances through." },
    ],
    revisionNotes:
      "Remember: PLANT cells have 3 extra features animal cells do not — Wall, chloroplast, big Vacuole (mnemonic: 'WCV'). Always compare, don't just list.",
  },
  {
    id: "mat-bio-2",
    subjectId: "biology",
    topicId: "genetics",
    title: "Mendelian Inheritance Basics",
    sample: true,
    explanation:
      "Gregor Mendel's experiments with pea plants established the basic laws of inheritance. Traits are controlled by pairs of alleles, one inherited from each parent; a dominant allele masks the effect of a recessive allele when both are present.",
    keyPoints: [
      "Genotype = the genetic makeup (e.g. Tt); phenotype = the observable trait.",
      "A homozygous genotype has two identical alleles (TT or tt).",
      "A heterozygous genotype has two different alleles (Tt).",
      "A Punnett square predicts the probable genotype ratios of offspring.",
      "Law of Segregation: allele pairs separate during gamete formation.",
    ],
    keyTerms: [
      { term: "Allele", def: "An alternative form of a gene, e.g. the gene for tallness has a tall and a short allele." },
      { term: "Dominant", def: "An allele that is expressed whenever it is present." },
      { term: "Recessive", def: "An allele only expressed when no dominant allele is present." },
    ],
    revisionNotes:
      "Practice drawing Punnett squares for monohybrid crosses (Tt x Tt) until the 3:1 ratio is automatic.",
  },
  {
    id: "mat-chem-1",
    subjectId: "chemistry",
    topicId: "atomic-structure",
    title: "Atoms, Protons, Neutrons & Electrons",
    sample: true,
    explanation:
      "An atom consists of a small, dense nucleus containing protons and neutrons, surrounded by electrons occupying energy levels (shells). The number of protons (atomic number) defines the element.",
    keyPoints: [
      "Protons: positive charge, mass ≈ 1; found in the nucleus.",
      "Neutrons: no charge, mass ≈ 1; found in the nucleus.",
      "Electrons: negative charge, negligible mass; occupy shells around the nucleus.",
      "Mass number = protons + neutrons.",
      "Isotopes have the same proton number but different neutron numbers.",
    ],
    keyTerms: [
      { term: "Atomic number (Z)", def: "The number of protons in an atom's nucleus." },
      { term: "Mass number (A)", def: "Protons + neutrons in the nucleus." },
      { term: "Isotope", def: "Atoms of the same element with different numbers of neutrons." },
    ],
    revisionNotes:
      "Electron configuration fills shells in order: 2, 8, 8 for the first three shells in simple IJMB-level questions.",
  },
  {
    id: "mat-chem-2",
    subjectId: "chemistry",
    topicId: "acids-bases",
    title: "Acids, Bases and the pH Scale",
    sample: true,
    explanation:
      "Acids release hydrogen ions (H+) in water while bases release hydroxide ions (OH-) or accept H+. The pH scale (0–14) measures how acidic or alkaline a solution is; 7 is neutral.",
    keyPoints: [
      "pH < 7 = acidic, pH = 7 = neutral, pH > 7 = alkaline (basic).",
      "A strong acid ionises completely in water; a weak acid only partially.",
      "Acid + Base → Salt + Water (neutralisation).",
      "Indicators such as litmus change colour to show pH.",
      "Common acids: HCl, H2SO4, CH3COOH. Common bases: NaOH, NH3.",
    ],
    keyTerms: [
      { term: "Neutralisation", def: "The reaction of an acid with a base to form a salt and water." },
      { term: "Indicator", def: "A substance that changes colour depending on pH." },
    ],
    revisionNotes:
      "Learn common salt names from acid + base pairs, e.g. HCl + NaOH → NaCl + H2O.",
  },
  {
    id: "mat-phy-1",
    subjectId: "physics",
    topicId: "mechanics",
    title: "Newton's Laws of Motion",
    sample: true,
    explanation:
      "Newton's three laws describe the relationship between a body and the forces acting on it, forming the foundation of classical mechanics.",
    keyPoints: [
      "1st Law (Inertia): an object stays at rest or in uniform motion unless acted on by a net force.",
      "2nd Law: F = ma — force equals mass times acceleration.",
      "3rd Law: for every action there is an equal and opposite reaction.",
      "Weight (W = mg) is a force; mass is a scalar quantity unaffected by gravity.",
      "Momentum (p = mv) is conserved in a closed system.",
    ],
    keyTerms: [
      { term: "Inertia", def: "The tendency of an object to resist a change in its state of motion." },
      { term: "Momentum", def: "The product of an object's mass and velocity." },
    ],
    revisionNotes:
      "Always keep units in SI (kg, m/s², N) before substituting into F = ma to avoid calculation errors.",
  },
  {
    id: "mat-phy-2",
    subjectId: "physics",
    topicId: "electricity",
    title: "Current Electricity & Ohm's Law",
    sample: true,
    explanation:
      "Electric current is the rate of flow of charge. Ohm's Law relates voltage, current and resistance in a conductor kept at constant temperature.",
    keyPoints: [
      "Ohm's Law: V = IR (Voltage = Current × Resistance).",
      "Current (I) is measured in amperes (A) using an ammeter connected in series.",
      "Voltage (V) is measured in volts using a voltmeter connected in parallel.",
      "Resistors in series: R_total = R1 + R2 + ...",
      "Resistors in parallel: 1/R_total = 1/R1 + 1/R2 + ...",
    ],
    keyTerms: [
      { term: "Resistance", def: "Opposition to the flow of electric current, measured in ohms (Ω)." },
      { term: "EMF", def: "Electromotive force — the energy supplied by a source per unit charge." },
    ],
    revisionNotes:
      "For circuit questions, redraw the circuit and label every component before applying Ohm's Law.",
  },
];

/* ---------- QUESTION BANK ------------------------------------
   Every question is SAMPLE/DEMO content for practising the CBT
   engine — not official IJMB past questions.
   difficulty: "easy" | "medium" | "hard"
---------------------------------------------------------------*/
const QUESTIONS = [
  // BIOLOGY — cell-structure
  { id: "q1", subjectId: "biology", topicId: "cell-structure", difficulty: "easy", sample: true,
    question: "Which organelle is described as the 'powerhouse of the cell'?",
    options: ["Nucleus", "Mitochondrion", "Ribosome", "Golgi body"], answer: 1,
    explanation: "Mitochondria carry out aerobic respiration, releasing energy as ATP." },
  { id: "q2", subjectId: "biology", topicId: "cell-structure", difficulty: "easy", sample: true,
    question: "Which structure is found in plant cells but NOT in animal cells?",
    options: ["Cell membrane", "Cytoplasm", "Cell wall", "Nucleus"], answer: 2,
    explanation: "The cellulose cell wall is unique to plant cells (and some other organisms), not animal cells." },
  { id: "q3", subjectId: "biology", topicId: "cell-structure", difficulty: "medium", sample: true,
    question: "The control centre of a cell that contains hereditary material is the:",
    options: ["Vacuole", "Nucleus", "Chloroplast", "Cell membrane"], answer: 1,
    explanation: "The nucleus houses DNA and directs the cell's activities." },
  { id: "q4", subjectId: "biology", topicId: "genetics", difficulty: "medium", sample: true,
    question: "In a cross Tt × Tt, what fraction of offspring is expected to show the recessive phenotype?",
    options: ["1/4", "1/2", "3/4", "0"], answer: 0,
    explanation: "A monohybrid cross Tt x Tt gives a 3:1 ratio (3 dominant : 1 recessive), so 1/4 shows recessive." },
  { id: "q5", subjectId: "biology", topicId: "genetics", difficulty: "easy", sample: true,
    question: "An organism with two identical alleles for a trait is said to be:",
    options: ["Heterozygous", "Homozygous", "Hybrid", "Diploid only"], answer: 1,
    explanation: "Homozygous means both alleles are identical, e.g. TT or tt." },
  { id: "q6", subjectId: "biology", topicId: "ecology", difficulty: "easy", sample: true,
    question: "The flow of energy through a series of organisms, each eating the one before it, is called a:",
    options: ["Food web", "Food chain", "Trophic pyramid", "Habitat"], answer: 1,
    explanation: "A food chain shows a single linear pathway of energy transfer between organisms." },
  { id: "q7", subjectId: "biology", topicId: "photosynthesis", difficulty: "medium", sample: true,
    question: "Which gas is released as a by-product of photosynthesis?",
    options: ["Carbon dioxide", "Nitrogen", "Oxygen", "Hydrogen"], answer: 2,
    explanation: "Photosynthesis converts CO2 and water into glucose and oxygen using light energy." },
  { id: "q8", subjectId: "biology", topicId: "photosynthesis", difficulty: "hard", sample: true,
    question: "The green pigment in chloroplasts that absorbs light energy for photosynthesis is:",
    options: ["Melanin", "Chlorophyll", "Haemoglobin", "Carotene"], answer: 1,
    explanation: "Chlorophyll absorbs mainly red and blue light, reflecting green light." },

  // CHEMISTRY
  { id: "q9", subjectId: "chemistry", topicId: "atomic-structure", difficulty: "easy", sample: true,
    question: "Which subatomic particle has no electrical charge?",
    options: ["Proton", "Electron", "Neutron", "Ion"], answer: 2,
    explanation: "Neutrons are neutral particles found in the nucleus alongside protons." },
  { id: "q10", subjectId: "chemistry", topicId: "atomic-structure", difficulty: "medium", sample: true,
    question: "Atoms of the same element with different numbers of neutrons are called:",
    options: ["Isomers", "Isotopes", "Ions", "Allotropes"], answer: 1,
    explanation: "Isotopes share the same proton number but differ in neutron number, e.g. Carbon-12 and Carbon-14." },
  { id: "q11", subjectId: "chemistry", topicId: "periodic-table", difficulty: "easy", sample: true,
    question: "Elements in the same group of the periodic table have the same number of:",
    options: ["Neutrons", "Valence electrons", "Protons", "Isotopes"], answer: 1,
    explanation: "Group number relates to the number of electrons in the outermost shell, giving similar chemistry." },
  { id: "q12", subjectId: "chemistry", topicId: "acids-bases", difficulty: "easy", sample: true,
    question: "A solution with pH 3 is best described as:",
    options: ["Strongly alkaline", "Neutral", "Acidic", "Weakly alkaline"], answer: 2,
    explanation: "Any pH below 7 is acidic; the lower the number, the more acidic." },
  { id: "q13", subjectId: "chemistry", topicId: "acids-bases", difficulty: "medium", sample: true,
    question: "The reaction HCl + NaOH → NaCl + H2O is an example of:",
    options: ["Oxidation", "Neutralisation", "Combustion", "Electrolysis"], answer: 1,
    explanation: "An acid reacting with a base to form a salt and water is a neutralisation reaction." },
  { id: "q14", subjectId: "chemistry", topicId: "organic-chem", difficulty: "medium", sample: true,
    question: "Which of the following is a saturated hydrocarbon?",
    options: ["Ethene", "Ethyne", "Ethane", "Benzene"], answer: 2,
    explanation: "Alkanes such as ethane contain only single C–C bonds, making them saturated." },
  { id: "q15", subjectId: "chemistry", topicId: "organic-chem", difficulty: "hard", sample: true,
    question: "The functional group –OH characterises which family of organic compounds?",
    options: ["Alkenes", "Alcohols", "Carboxylic acids", "Esters"], answer: 1,
    explanation: "Alcohols are characterised by the hydroxyl (-OH) functional group." },

  // PHYSICS
  { id: "q16", subjectId: "physics", topicId: "mechanics", difficulty: "easy", sample: true,
    question: "Newton's Second Law is expressed as:",
    options: ["F = mv", "F = ma", "F = m/a", "F = a/m"], answer: 1,
    explanation: "Force equals mass multiplied by acceleration (F = ma)." },
  { id: "q17", subjectId: "physics", topicId: "mechanics", difficulty: "medium", sample: true,
    question: "A body moving at constant velocity has a net force acting on it equal to:",
    options: ["Zero", "Its weight", "Maximum", "Equal to mass"], answer: 0,
    explanation: "By Newton's First Law, constant velocity means the net (resultant) force is zero." },
  { id: "q18", subjectId: "physics", topicId: "electricity", difficulty: "easy", sample: true,
    question: "According to Ohm's Law, V equals:",
    options: ["I/R", "I + R", "IR", "R/I"], answer: 2,
    explanation: "Ohm's Law: V = IR (Voltage = Current x Resistance)." },
  { id: "q19", subjectId: "physics", topicId: "electricity", difficulty: "medium", sample: true,
    question: "An ammeter is always connected in ___ with the circuit component.",
    options: ["Series", "Parallel", "Reverse", "Isolation"], answer: 0,
    explanation: "Ammeters are connected in series so the same current flows through the meter and the component." },
  { id: "q20", subjectId: "physics", topicId: "waves", difficulty: "medium", sample: true,
    question: "The distance between two successive crests of a wave is called its:",
    options: ["Amplitude", "Frequency", "Wavelength", "Period"], answer: 2,
    explanation: "Wavelength is the distance between corresponding points on successive waves, e.g. crest to crest." },
  { id: "q21", subjectId: "physics", topicId: "thermo", difficulty: "hard", sample: true,
    question: "The transfer of heat through a vacuum occurs mainly by:",
    options: ["Conduction", "Convection", "Radiation", "Diffusion"], answer: 2,
    explanation: "Radiation does not need a medium, so it is the only heat transfer method that works through a vacuum." },
];

/* ---------- ANNOUNCEMENTS -------------------------------------
   Local/demo announcements. A real backend can later replace
   this array with data fetched from an API — see js/app.js
   loadAnnouncements() which is written to make that swap easy.
---------------------------------------------------------------*/
const ANNOUNCEMENTS = [
  {
    id: "a1",
    type: "reminder",
    title: "Keep a daily practice streak",
    body: "Aim for at least 10 CBT practice questions a day across your three subjects to build exam speed and accuracy.",
    date: "2026-08-01",
  },
  {
    id: "a2",
    type: "exam",
    title: "IJMB examinations are approached in sessions",
    body: "Check with your coordinating centre for your official examination timetable — this app is a personal study aid and does not publish official IJMB dates.",
    date: "2026-08-01",
  },
  {
    id: "a3",
    type: "study",
    title: "New topics added: Organic Chemistry & Thermodynamics",
    body: "We've added fresh sample materials and practice questions for Organic Chemistry and Heat & Thermodynamics. Check them out in Study Materials.",
    date: "2026-07-20",
  },
];

/* Exposed globally for app.js (no module bundler required, so
   GitHub Pages can serve this as plain static files). */
window.SUBJECTS = SUBJECTS;
window.MATERIALS = MATERIALS;
window.QUESTIONS = QUESTIONS;
window.ANNOUNCEMENTS = ANNOUNCEMENTS;
