/* ============================================================
   IJMB STUDENT HUB — storage.js
   Small, reusable wrapper around localStorage. Every read/write
   in the app goes through here so that:
     - a missing/corrupted key never crashes the app
     - all storage keys live in one place (STORE_KEYS)
     - swapping localStorage for a real backend later only means
       editing the functions in this one file
   ============================================================ */

const STORE_KEYS = {
  PROFILE: "ijmb_profile",
  QUIZ_HISTORY: "ijmb_quiz_history",
  BOOKMARKS: "ijmb_bookmarks",
  TIMETABLE: "ijmb_timetable",
  SETTINGS: "ijmb_settings",
  TOPIC_PROGRESS: "ijmb_topic_progress",
  ACTIVITY: "ijmb_recent_activity",
  QUIZ_IN_PROGRESS: "ijmb_quiz_in_progress",
};

const DEFAULTS = {
  [STORE_KEYS.PROFILE]: {
    name: "",
    email: "",
    institution: "",
    programme: "",
    subjects: [],
  },
  [STORE_KEYS.QUIZ_HISTORY]: [],
  [STORE_KEYS.BOOKMARKS]: { questions: [], materials: [] },
  [STORE_KEYS.TIMETABLE]: [],
  [STORE_KEYS.SETTINGS]: { theme: "light" },
  [STORE_KEYS.TOPIC_PROGRESS]: {}, // { topicId: { attempted, correct } }
  [STORE_KEYS.ACTIVITY]: [],
  [STORE_KEYS.QUIZ_IN_PROGRESS]: null,
};

/**
 * Check whether localStorage is actually usable (private browsing,
 * disabled storage, or quota-full environments can all throw).
 */
function isStorageAvailable() {
  try {
    const testKey = "__ijmb_test__";
    window.localStorage.setItem(testKey, "1");
    window.localStorage.removeItem(testKey);
    return true;
  } catch (e) {
    return false;
  }
}

const STORAGE_OK = isStorageAvailable();
// In-memory fallback used only if localStorage is unavailable, so the
// app still works for the current session instead of crashing.
const memoryFallback = {};

/** Read a key from storage, falling back to a sane default. */
function loadData(key) {
  const fallbackValue = DEFAULTS.hasOwnProperty(key) ? DEFAULTS[key] : null;
  if (!STORAGE_OK) {
    return memoryFallback.hasOwnProperty(key) ? memoryFallback[key] : fallbackValue;
  }
  try {
    const raw = window.localStorage.getItem(key);
    if (raw === null || raw === undefined) return fallbackValue;
    return JSON.parse(raw);
  } catch (e) {
    console.warn("IJMB Hub: could not read '" + key + "' from storage, using default.", e);
    return fallbackValue;
  }
}

/** Write a key to storage. Returns true on success, false on failure. */
function saveData(key, value) {
  if (!STORAGE_OK) {
    memoryFallback[key] = value;
    return true;
  }
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.warn("IJMB Hub: could not save '" + key + "' to storage.", e);
    memoryFallback[key] = value;
    return false;
  }
}

/** Remove a single key, resetting it back to its default. */
function clearData(key) {
  if (!STORAGE_OK) {
    delete memoryFallback[key];
    return true;
  }
  try {
    window.localStorage.removeItem(key);
    return true;
  } catch (e) {
    return false;
  }
}

/** Log a short line of recent activity (max 20 kept). */
function logActivity(text) {
  const activity = loadData(STORE_KEYS.ACTIVITY) || [];
  activity.unshift({ text: text, time: new Date().toISOString() });
  saveData(STORE_KEYS.ACTIVITY, activity.slice(0, 20));
}
