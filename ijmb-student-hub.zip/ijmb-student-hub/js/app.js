/* ============================================================
   IJMB STUDENT HUB — app.js
   Hash-based single-page router + all view rendering + the CBT
   quiz engine. No build step / framework — plain DOM string
   templates re-rendered into #view on every navigation, with a
   single delegated click handler for actions.
   ============================================================ */

/* ---------------------------------------------------------------
   NAV CONFIG — edit this array to add/remove/re-order nav items.
   Bottom nav (mobile) shows the first 5; the sidebar (desktop)
   shows all of them.
------------------------------------------------------------------*/
const NAV_ITEMS = [
  { hash: "#/dashboard", label: "Home", icon: "🏠" },
  { hash: "#/subjects", label: "Subjects", icon: "📚" },
  { hash: "#/quiz/setup", label: "Quiz", icon: "📝" },
  { hash: "#/timetable", label: "Planner", icon: "🗓️" },
  { hash: "#/more", label: "More", icon: "⋯" },
];

const SIDEBAR_ITEMS = [
  { hash: "#/dashboard", label: "Dashboard", icon: "🏠" },
  { hash: "#/subjects", label: "Subjects", icon: "📚" },
  { hash: "#/quiz/setup", label: "CBT Practice", icon: "📝" },
  { hash: "#/questions", label: "Question Bank", icon: "🗂️" },
  { hash: "#/scores", label: "Score Tracker", icon: "📈" },
  { hash: "#/timetable", label: "Timetable", icon: "🗓️" },
  { hash: "#/progress", label: "Progress", icon: "🎯" },
  { hash: "#/bookmarks", label: "Bookmarks", icon: "🔖" },
  { hash: "#/announcements", label: "Announcements", icon: "📢" },
  { hash: "#/calculators", label: "Calculators", icon: "🧮" },
  { hash: "#/profile", label: "Profile", icon: "👤" },
  { hash: "#/settings", label: "Settings", icon: "⚙️" },
];

/* ---------------------------------------------------------------
   GLOBAL RUNTIME STATE (not persisted directly — quiz state is
   mirrored to localStorage separately so a refresh mid-quiz does
   not lose progress).
------------------------------------------------------------------*/
const state = {
  quiz: null,          // active quiz object, see startQuiz()
  quizTimerId: null,
  searchTerm: "",
  questionFilters: { subject: "all", topic: "all", difficulty: "all" },
  bookmarkTab: "questions",
  calcTab: "basic",
  calcExpr: "",
};

/* ================= UTILITIES ================= */

function $(selector, root) { return (root || document).querySelector(selector); }
function $all(selector, root) { return Array.from((root || document).querySelectorAll(selector)); }

function escapeHtml(str) {
  if (str === undefined || str === null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function uid(prefix) {
  return (prefix || "id") + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function formatDate(iso, opts) {
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso || "";
    return d.toLocaleDateString("en-GB", opts || { day: "numeric", month: "short", year: "numeric" });
  } catch (e) {
    return iso || "";
  }
}

function formatTime(seconds) {
  const s = Math.max(0, Math.floor(seconds));
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return String(m).padStart(2, "0") + ":" + String(sec).padStart(2, "0");
}

function subjectById(id) { return SUBJECTS.find((s) => s.id === id); }
function topicById(subjectId, topicId) {
  const subj = subjectById(subjectId);
  return subj ? subj.topics.find((t) => t.id === topicId) : null;
}
function subjectColor(id) {
  const s = subjectById(id);
  return s ? s.color : "var(--navy-800)";
}

let toastTimer = null;
function showToast(message, type) {
  let wrap = $(".toast-wrap");
  if (!wrap) {
    wrap = document.createElement("div");
    wrap.className = "toast-wrap";
    document.body.appendChild(wrap);
  }
  const toast = document.createElement("div");
  toast.className = "toast" + (type ? " " + type : "");
  toast.textContent = message;
  wrap.appendChild(toast);
  setTimeout(() => toast.remove(), 3200);
}

function svgRing(pct, size, color, strokeWidth) {
  size = size || 64;
  strokeWidth = strokeWidth || 7;
  const r = (size - strokeWidth) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.min(100, Math.max(0, pct)) / 100) * c;
  return (
    '<svg viewBox="0 0 ' + size + " " + size + '">' +
    '<circle class="ring-bg" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '"></circle>' +
    '<circle class="ring-fg" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r +
    '" stroke="' + color + '" stroke-dasharray="' + c + '" stroke-dashoffset="' + offset + '"></circle>' +
    "</svg>"
  );
}

/* ================= PROGRESS HELPERS ================= */

function getTopicProgress(topicId) {
  const all = loadData(STORE_KEYS.TOPIC_PROGRESS) || {};
  return all[topicId] || { attempted: 0, correct: 0 };
}

function recordTopicProgress(topicId, wasCorrect) {
  const all = loadData(STORE_KEYS.TOPIC_PROGRESS) || {};
  const cur = all[topicId] || { attempted: 0, correct: 0 };
  cur.attempted += 1;
  if (wasCorrect) cur.correct += 1;
  all[topicId] = cur;
  saveData(STORE_KEYS.TOPIC_PROGRESS, all);
}

function subjectProgressPct(subjectId) {
  const subj = subjectById(subjectId);
  if (!subj) return 0;
  let attempted = 0, correct = 0;
  subj.topics.forEach((t) => {
    const p = getTopicProgress(t.id);
    attempted += p.attempted;
    correct += p.correct;
  });
  if (attempted === 0) return 0;
  return Math.round((correct / attempted) * 100);
}

function overallStats() {
  const history = loadData(STORE_KEYS.QUIZ_HISTORY) || [];
  let attempted = 0, correct = 0;
  const progress = loadData(STORE_KEYS.TOPIC_PROGRESS) || {};
  Object.keys(progress).forEach((k) => {
    attempted += progress[k].attempted;
    correct += progress[k].correct;
  });
  const avgScore = history.length
    ? Math.round(history.reduce((sum, h) => sum + h.percentage, 0) / history.length)
    : 0;
  return { attempted, correct, avgScore, quizCount: history.length };
}

/* ================= ROUTER ================= */

function parseRoute() {
  const hash = window.location.hash || "#/dashboard";
  const parts = hash.replace(/^#\//, "").split("/").filter(Boolean);
  return { hash, parts };
}

function navigateTo(hash) {
  if (window.location.hash === hash) {
    render();
  } else {
    window.location.hash = hash;
  }
}

function render() {
  const { hash, parts } = parseRoute();
  const view = document.getElementById("view");
  if (!view) return;

  // Warn before leaving an in-progress quiz via nav (data loss guard)
  view.innerHTML = renderRoute(parts, hash);
  window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  updateNavActiveState(hash);
  mountRoute(parts, hash);
}

/**
 * Pure "what HTML should this route show" function.
 */
function renderRoute(parts, hash) {
  const root = parts[0];
  try {
    switch (root) {
      case undefined:
      case "dashboard":
        return viewDashboard();
      case "profile":
        return viewProfile();
      case "subjects":
        return viewSubjects();
      case "subject":
        if (parts[2] === "topic" && parts[3]) return viewTopic(parts[1], parts[3]);
        return viewSubjectDetail(parts[1]);
      case "material":
        return viewMaterialDetail(parts[1]);
      case "quiz":
        if (parts[1] === "setup") return viewQuizSetup();
        if (parts[1] === "run") return viewQuizRunning();
        if (parts[1] === "result") return viewQuizResult();
        return viewQuizSetup();
      case "questions":
        return viewQuestionBank();
      case "scores":
        return viewScoreTracker();
      case "timetable":
        return viewTimetable();
      case "progress":
        return viewProgress();
      case "bookmarks":
        return viewBookmarks();
      case "search":
        return viewSearch();
      case "announcements":
        return viewAnnouncements();
      case "calculators":
        return viewCalculators();
      case "settings":
        return viewSettings();
      case "more":
        return viewMore();
      default:
        return viewNotFound();
    }
  } catch (err) {
    console.error("Render error for route", hash, err);
    return (
      '<div class="empty-state"><div class="emoji">⚠️</div>' +
      "<h3>Something went wrong showing this page</h3>" +
      '<p class="muted">Please try going back to the dashboard.</p>' +
      '<button class="btn btn-primary mt-2" data-action="go" data-hash="#/dashboard">Back to Dashboard</button></div>'
    );
  }
}

/**
 * Attach any listeners/behaviour that can't be done via the single
 * delegated click handler (timers, focus, chart draw, etc.)
 */
function mountRoute(parts, hash) {
  const root = parts[0];
  if (root === "quiz" && parts[1] === "run") {
    startQuizTimerLoop();
  } else {
    stopQuizTimerLoop();
  }
  if (root === "search") {
    const input = $("#globalSearchInput");
    if (input) input.focus();
  }
  if (root === "calculators") {
    renderCalcDisplay();
  }
}

/* ================= NAV RENDERING ================= */

function renderTopbar() {
  return (
    '<header class="topbar">' +
    '<div class="brand"><span class="logo-mark">IJ</span><span>IJMB Student Hub</span></div>' +
    '<div class="topbar-actions">' +
    '<button class="icon-btn" data-action="go" data-hash="#/search" aria-label="Search">🔍</button>' +
    '<button class="icon-btn" data-action="go" data-hash="#/announcements" aria-label="Announcements">🔔</button>' +
    '<button class="icon-btn" data-action="toggle-theme" aria-label="Toggle dark mode">' + (getTheme() === "dark" ? "☀️" : "🌙") + "</button>" +
    "</div></header>"
  );
}

function renderBottomNav() {
  return (
    '<nav class="bottom-nav" id="bottomNav">' +
    NAV_ITEMS.map(
      (item) =>
        '<button class="nav-item" data-action="go" data-hash="' + item.hash + '" data-navhash="' + item.hash + '">' +
        '<span class="nav-icon">' + item.icon + "</span><span>" + item.label + "</span></button>"
    ).join("") +
    "</nav>"
  );
}

function renderSidebar() {
  return (
    '<aside class="sidebar" id="sidebarNav">' +
    SIDEBAR_ITEMS.map(
      (item) =>
        '<button class="nav-item" data-action="go" data-hash="' + item.hash + '" data-navhash="' + item.hash + '">' +
        '<span class="nav-icon">' + item.icon + "</span><span>" + item.label + "</span></button>"
    ).join("") +
    "</aside>"
  );
}

function updateNavActiveState(hash) {
  const topLevel = "#/" + (hash.replace(/^#\//, "").split("/")[0] || "dashboard");
  $all("#bottomNav .nav-item").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.navhash === topLevel || (topLevel === "#/quiz" && btn.dataset.navhash === "#/quiz/setup"));
  });
  $all("#sidebarNav .nav-item").forEach((btn) => {
    const match = btn.dataset.navhash === topLevel || (topLevel === "#/quiz" && btn.dataset.navhash === "#/quiz/setup");
    btn.classList.toggle("active", match);
  });
  // refresh topbar theme icon
  const themeBtn = $('[data-action="toggle-theme"]');
  if (themeBtn) themeBtn.textContent = getTheme() === "dark" ? "☀️" : "🌙";
}

/* ================= THEME ================= */

function getTheme() {
  const settings = loadData(STORE_KEYS.SETTINGS) || DEFAULTS[STORE_KEYS.SETTINGS];
  return settings.theme === "dark" ? "dark" : "light";
}

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  const settings = loadData(STORE_KEYS.SETTINGS) || {};
  settings.theme = theme;
  saveData(STORE_KEYS.SETTINGS, settings);
}

function toggleTheme() {
  const next = getTheme() === "dark" ? "light" : "dark";
  applyTheme(next);
  render();
}

/* ================= APP SHELL (built once) ================= */
/* The topbar / sidebar / bottom-nav are part of the static shell,
   built once at startup from the render*Nav() functions above.
   Only <main id="view"> is replaced on every navigation. */
function buildShell() {
  const app = document.getElementById("app");
  app.innerHTML =
    renderTopbar() +
    '<div class="layout">' +
    renderSidebar() +
    '<main id="view"></main>' +
    "</div>" +
    renderBottomNav();
}

/* ================= VIEW: DASHBOARD ================= */

function viewDashboard() {
  const profile = loadData(STORE_KEYS.PROFILE) || DEFAULTS[STORE_KEYS.PROFILE];
  const stats = overallStats();
  const activity = (loadData(STORE_KEYS.ACTIVITY) || []).slice(0, 5);
  const upcoming = (loadData(STORE_KEYS.TIMETABLE) || [])
    .filter((s) => !s.completed && new Date(s.date + "T" + (s.time || "00:00")) >= new Date(new Date().toDateString()))
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))
    .slice(0, 3);
  const name = profile.name ? profile.name.split(" ")[0] : "Student";

  return (
    '<div class="hero-card">' +
    "<h1>Welcome back, " + escapeHtml(name) + "! 👋</h1>" +
    "<p>" + (stats.quizCount > 0
      ? "You've completed " + stats.quizCount + " quiz" + (stats.quizCount === 1 ? "" : "zes") + " with a " + stats.avgScore + "% average. Keep going!"
      : "Ready to start preparing? Try a quick CBT practice quiz today.") +
    "</p>" +
    '<button class="btn btn-accent mt-2" data-action="go" data-hash="#/quiz/setup">Start a practice quiz →</button>' +
    "</div>" +

    '<div class="grid grid-3 mt-3">' +
    '<div class="card stat-card"><div class="stat-value">' + stats.attempted + '</div><div class="stat-label">Questions attempted</div></div>' +
    '<div class="card stat-card"><div class="stat-value">' + stats.avgScore + '%</div><div class="stat-label">Average quiz score</div></div>' +
    '<div class="card stat-card"><div class="stat-value">' + stats.quizCount + '</div><div class="stat-label">Quizzes completed</div></div>' +
    "</div>" +

    '<h2 class="section-title mt-3">Quick actions</h2>' +
    '<div class="grid grid-3 mt-1">' +
    '<button class="quick-btn" data-action="go" data-hash="#/quiz/setup"><span class="qb-icon">📝</span>Quiz</button>' +
    '<button class="quick-btn" data-action="go" data-hash="#/subjects"><span class="qb-icon">📖</span>Materials</button>' +
    '<button class="quick-btn" data-action="go" data-hash="#/timetable"><span class="qb-icon">🗓️</span>Timetable</button>' +
    '<button class="quick-btn" data-action="go" data-hash="#/scores"><span class="qb-icon">📈</span>Results</button>' +
    '<button class="quick-btn" data-action="go" data-hash="#/questions"><span class="qb-icon">🗂️</span>Question Bank</button>' +
    '<button class="quick-btn" data-action="go" data-hash="#/calculators"><span class="qb-icon">🧮</span>Calculators</button>' +
    "</div>" +

    '<h2 class="section-title mt-3">Your subjects</h2>' +
    '<div class="stack mt-1">' +
    SUBJECTS.map((s) => {
      const pct = subjectProgressPct(s.id);
      return (
        '<div class="card subject-card" data-action="go" data-hash="#/subject/' + s.id + '">' +
        '<div class="subject-icon" style="background:' + s.color + '">' + s.icon + "</div>" +
        '<div style="flex:1"><h3>' + s.name + "</h3>" +
        '<div class="progress-bar mt-1"><span style="width:' + pct + '%; background:' + s.color + '"></span></div></div>' +
        '<div class="ring-wrap">' + svgRing(pct, 46, s.color, 6) + '<div class="ring-label">' + pct + "%</div></div>" +
        "</div>"
      );
    }).join("") +
    "</div>" +

    (upcoming.length
      ? '<h2 class="section-title mt-3">Upcoming study sessions</h2>' +
        '<div class="stack mt-1">' +
        upcoming.map((s) => timetableItemHtml(s)).join("") +
        "</div>"
      : "") +

    '<h2 class="section-title mt-3">Recent activity</h2>' +
    '<div class="card mt-1">' +
    (activity.length
      ? activity.map((a) => '<div class="activity-item"><span class="dot"></span><div><div>' + escapeHtml(a.text) + '</div><div class="activity-time">' + formatDate(a.time, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) + "</div></div></div>").join("")
      : '<div class="empty-state"><div class="emoji">📌</div><p>No activity yet. Start a quiz or browse materials to see your activity here.</p></div>') +
    "</div>"
  );
}

/* ================= VIEW: PROFILE ================= */

function viewProfile() {
  const p = loadData(STORE_KEYS.PROFILE) || DEFAULTS[STORE_KEYS.PROFILE];
  const hasProfile = !!(p.name || p.email);
  return (
    '<div class="page-title-row"><h2>Student Profile</h2></div>' +
    '<div class="card">' +
    '<form data-form="profile" novalidate>' +
    '<div class="field"><label for="pf-name">Full name</label><input id="pf-name" name="name" type="text" placeholder="e.g. Amaka Johnson" value="' + escapeHtml(p.name) + '" required></div>' +
    '<div class="field"><label for="pf-email">Email address</label><input id="pf-email" name="email" type="email" placeholder="you@example.com" value="' + escapeHtml(p.email) + '"></div>' +
    '<div class="field"><label for="pf-inst">Institution</label><input id="pf-inst" name="institution" type="text" placeholder="e.g. ABU Zaria IJMB Centre" value="' + escapeHtml(p.institution) + '"></div>' +
    '<div class="field"><label for="pf-prog">IJMB Programme / Session</label><input id="pf-prog" name="programme" type="text" placeholder="e.g. 2025/2026 Session" value="' + escapeHtml(p.programme) + '"></div>' +
    '<div class="field"><label>Preferred subjects</label><div class="row wrap">' +
    SUBJECTS.map((s) =>
      '<label class="tab-btn' + (p.subjects.includes(s.id) ? " active" : "") + '" style="cursor:pointer;display:inline-flex;align-items:center;gap:6px;">' +
      '<input type="checkbox" name="subjects" value="' + s.id + '" ' + (p.subjects.includes(s.id) ? "checked" : "") + ' style="width:auto;margin:0;">' + s.icon + " " + s.name + "</label>"
    ).join("") +
    "</div></div>" +
    '<div id="profileErr" class="small" style="color:var(--coral)"></div>' +
    '<button type="submit" class="btn btn-primary btn-block mt-2">Save profile</button>' +
    "</form></div>" +
    (hasProfile
      ? '<p class="muted small center mt-2">Your profile is saved on this device only.</p>'
      : '<p class="muted small center mt-2">Fill in your details so the dashboard can greet you by name.</p>')
  );
}

/* ================= VIEW: SUBJECTS ================= */

function viewSubjects() {
  return (
    '<div class="page-title-row"><h2>Subjects</h2></div>' +
    '<p class="muted small">Tap a subject to see its topics, study materials and practice quizzes.</p>' +
    '<div class="stack mt-2">' +
    SUBJECTS.map((s) => {
      const pct = subjectProgressPct(s.id);
      const matCount = MATERIALS.filter((m) => m.subjectId === s.id).length;
      const qCount = QUESTIONS.filter((q) => q.subjectId === s.id).length;
      return (
        '<div class="card subject-card" data-action="go" data-hash="#/subject/' + s.id + '">' +
        '<div class="subject-icon" style="background:' + s.color + '">' + s.icon + "</div>" +
        '<div style="flex:1"><h3>' + s.name + "</h3>" +
        '<p class="muted small mt-0">' + s.topics.length + " topics · " + matCount + " materials · " + qCount + ' sample questions</p>' +
        '<div class="progress-bar mt-1"><span style="width:' + pct + '%; background:' + s.color + '"></span></div></div>' +
        '<div class="ring-wrap">' + svgRing(pct, 46, s.color, 6) + '<div class="ring-label">' + pct + "%</div></div>" +
        "</div>"
      );
    }).join("") +
    "</div>"
  );
}

function viewSubjectDetail(subjectId) {
  const s = subjectById(subjectId);
  if (!s) return viewNotFound();
  return (
    '<div class="page-title-row"><button class="back-btn" data-action="go" data-hash="#/subjects">←</button><h2>' + s.icon + " " + s.name + "</h2></div>" +
    '<div class="card row between">' +
    '<div><div class="stat-value" style="font-family:var(--font-display);font-size:1.4rem">' + subjectProgressPct(s.id) + '%</div><div class="stat-label muted small">Overall accuracy</div></div>' +
    '<button class="btn btn-accent" data-action="quiz-quick-start" data-subject="' + s.id + '">Practice this subject</button>' +
    "</div>" +
    '<h3 class="section-title mt-3">Topics</h3>' +
    '<div class="mt-1">' +
    s.topics.map((t) => {
      const p = getTopicProgress(t.id);
      const pct = p.attempted ? Math.round((p.correct / p.attempted) * 100) : 0;
      return (
        '<div class="topic-row" data-action="go" data-hash="#/subject/' + s.id + "/topic/" + t.id + '">' +
        '<div><div style="font-weight:600">' + t.name + '</div><div class="muted small">' + (p.attempted ? pct + "% accuracy · " + p.attempted + " attempted" : "Not started yet") + "</div></div>" +
        '<span class="muted">›</span></div>'
      );
    }).join("") +
    "</div>"
  );
}

function viewTopic(subjectId, topicId) {
  const s = subjectById(subjectId);
  const t = topicById(subjectId, topicId);
  if (!s || !t) return viewNotFound();
  const materials = MATERIALS.filter((m) => m.subjectId === subjectId && m.topicId === topicId);
  const questions = QUESTIONS.filter((q) => q.subjectId === subjectId && q.topicId === topicId);
  const p = getTopicProgress(topicId);
  const pct = p.attempted ? Math.round((p.correct / p.attempted) * 100) : 0;

  return (
    '<div class="page-title-row"><button class="back-btn" data-action="go" data-hash="#/subject/' + subjectId + '">←</button><h2>' + t.name + "</h2></div>" +
    '<div class="card row between">' +
    '<div class="ring-wrap">' + svgRing(pct, 56, s.color, 6) + '<div class="ring-label">' + pct + "%</div></div>" +
    '<div style="flex:1;margin-left:8px"><div class="muted small">' + p.attempted + " questions attempted · " + p.correct + " correct</div></div>" +
    '<button class="btn btn-primary" data-action="quiz-quick-start" data-subject="' + subjectId + '" data-topic="' + topicId + '">Practice</button>' +
    "</div>" +
    '<h3 class="section-title mt-3">Study materials</h3>' +
    '<div class="mt-1">' +
    (materials.length
      ? materials.map((m) => materialItemHtml(m)).join("")
      : '<div class="empty-state"><div class="emoji">📄</div><p>No materials for this topic yet.</p></div>') +
    "</div>" +
    '<h3 class="section-title mt-3">Sample practice questions (' + questions.length + ")</h3>" +
    '<p class="muted small">View them in the full <a data-action="go" data-hash="#/questions" style="color:var(--navy-800);font-weight:600">Question Bank</a>, or tap Practice above to take a timed quiz.</p>'
  );
}

function materialItemHtml(m) {
  return (
    '<div class="material-item" data-action="go" data-hash="#/material/' + m.id + '">' +
    '<div class="row between"><h4 style="font-size:0.98rem">' + escapeHtml(m.title) + "</h4>" +
    (m.sample ? '<span class="badge badge-sample">SAMPLE</span>' : "") + "</div>" +
    '<p class="muted small mt-0" style="margin-top:4px">' + escapeHtml(m.explanation).slice(0, 100) + "…</p>" +
    "</div>"
  );
}

/* ================= VIEW: MATERIAL DETAIL ================= */

function viewMaterialDetail(materialId) {
  const m = MATERIALS.find((x) => x.id === materialId);
  if (!m) return viewNotFound();
  const s = subjectById(m.subjectId);
  const t = topicById(m.subjectId, m.topicId);
  const bookmarks = loadData(STORE_KEYS.BOOKMARKS) || DEFAULTS[STORE_KEYS.BOOKMARKS];
  const isBookmarked = bookmarks.materials.includes(m.id);

  return (
    '<div class="page-title-row"><button class="back-btn" data-action="go" data-hash="#/subject/' + m.subjectId + "/topic/" + m.topicId + '">←</button>' +
    '<h2 style="font-size:1.05rem">' + escapeHtml(t ? t.name : "") + "</h2></div>" +
    '<div class="card material-detail">' +
    '<div class="row between"><span class="badge" style="background:' + s.color + '22;color:' + s.color + '">' + s.name + "</span>" +
    (m.sample ? '<span class="badge badge-sample">SAMPLE CONTENT</span>' : "") + "</div>" +
    "<h2 class=\"mt-1\">" + escapeHtml(m.title) + "</h2>" +
    '<p class="mt-1">' + escapeHtml(m.explanation) + "</p>" +
    '<h4 class="section-title mt-3">Important points</h4>' +
    '<ul class="bullet-list">' + m.keyPoints.map((k) => "<li>" + escapeHtml(k) + "</li>").join("") + "</ul>" +
    '<h4 class="section-title mt-3">Key terms</h4>' +
    m.keyTerms.map((kt) => '<div class="key-term"><b>' + escapeHtml(kt.term) + ":</b> " + escapeHtml(kt.def) + "</div>").join("") +
    '<h4 class="section-title mt-3">Revision notes</h4>' +
    '<p class="mt-1">' + escapeHtml(m.revisionNotes) + "</p>" +
    '<button class="btn ' + (isBookmarked ? "btn-danger" : "btn-ghost") + ' btn-block mt-3" data-action="toggle-bookmark-material" data-id="' + m.id + '">' +
    (isBookmarked ? "🔖 Remove bookmark" : "🔖 Bookmark this material") + "</button>" +
    "</div>"
  );
}

/* ================= VIEW: QUESTION BANK ================= */

function filteredQuestions() {
  const f = state.questionFilters;
  return QUESTIONS.filter((q) => {
    if (f.subject !== "all" && q.subjectId !== f.subject) return false;
    if (f.topic !== "all" && q.topicId !== f.topic) return false;
    if (f.difficulty !== "all" && q.difficulty !== f.difficulty) return false;
    return true;
  });
}

function viewQuestionBank() {
  const f = state.questionFilters;
  const subj = f.subject !== "all" ? subjectById(f.subject) : null;
  const topics = subj ? subj.topics : [];
  const results = filteredQuestions();
  const bookmarks = loadData(STORE_KEYS.BOOKMARKS) || DEFAULTS[STORE_KEYS.BOOKMARKS];

  return (
    '<div class="page-title-row"><h2>Question Bank</h2></div>' +
    '<p class="muted small">All questions below are <b>sample/demo content</b> written for practising with this app — not official IJMB past questions.</p>' +
    '<div class="card mt-2">' +
    '<div class="field"><label>Subject</label><select id="qf-subject">' +
    '<option value="all">All subjects</option>' +
    SUBJECTS.map((s) => '<option value="' + s.id + '"' + (f.subject === s.id ? " selected" : "") + ">" + s.name + "</option>").join("") +
    "</select></div>" +
    '<div class="field"><label>Topic</label><select id="qf-topic" ' + (topics.length ? "" : "disabled") + ">" +
    '<option value="all">All topics</option>' +
    topics.map((t) => '<option value="' + t.id + '"' + (f.topic === t.id ? " selected" : "") + ">" + t.name + "</option>").join("") +
    "</select></div>" +
    '<div class="field mt-0"><label>Difficulty</label><div class="tab-bar">' +
    ["all", "easy", "medium", "hard"].map((d) =>
      '<button class="tab-btn' + (f.difficulty === d ? " active" : "") + '" data-action="qf-difficulty" data-value="' + d + '">' + (d === "all" ? "All" : d[0].toUpperCase() + d.slice(1)) + "</button>"
    ).join("") + "</div></div>" +
    "</div>" +
    '<p class="muted small mt-2">' + results.length + " question" + (results.length === 1 ? "" : "s") + " found</p>" +
    '<div class="stack mt-1">' +
    (results.length
      ? results.map((q) => questionAccordionHtml(q, bookmarks.questions.includes(q.id))).join("")
      : '<div class="empty-state"><div class="emoji">🔍</div><p>No questions match these filters.</p></div>') +
    "</div>"
  );
}

function questionAccordionHtml(q, isBookmarked) {
  const s = subjectById(q.subjectId);
  const letters = ["A", "B", "C", "D"];
  return (
    '<div class="card">' +
    '<div class="row between wrap" style="gap:6px">' +
    '<span class="badge" style="background:' + s.color + '22;color:' + s.color + '">' + s.name + "</span>" +
    '<span class="badge badge-' + q.difficulty + '">' + q.difficulty.toUpperCase() + "</span>" +
    '<span class="badge badge-sample">SAMPLE</span>' +
    "</div>" +
    '<p style="font-weight:600;margin-top:10px">' + escapeHtml(q.question) + "</p>" +
    '<div class="mt-1">' +
    q.options.map((opt, i) =>
      '<div class="key-term" style="' + (i === q.answer ? "color:var(--green);font-weight:600" : "") + '">' + letters[i] + ". " + escapeHtml(opt) + (i === q.answer ? " ✓" : "") + "</div>"
    ).join("") +
    "</div>" +
    '<details class="mt-1"><summary class="small muted" style="cursor:pointer">Show explanation</summary><p class="small mt-1">' + escapeHtml(q.explanation) + "</p></details>" +
    '<button class="btn btn-sm ' + (isBookmarked ? "btn-danger" : "btn-ghost") + ' mt-2" data-action="toggle-bookmark-question" data-id="' + q.id + '">' +
    (isBookmarked ? "🔖 Remove bookmark" : "🔖 Bookmark") + "</button>" +
    "</div>"
  );
}

/* ================= QUIZ ENGINE: SETUP ================= */

function viewQuizSetup() {
  // resume banner if a quiz is already in progress
  const inProgress = loadData(STORE_KEYS.QUIZ_IN_PROGRESS);
  const defaultSubject = SUBJECTS[0];
  return (
    '<div class="page-title-row"><h2>CBT Practice Quiz</h2></div>' +
    (inProgress
      ? '<div class="card mt-1" style="border-color:var(--amber)"><div class="row between">' +
        '<div><b>You have a quiz in progress</b><div class="muted small">Question ' + (inProgress.current + 1) + " of " + inProgress.questionIds.length + "</div></div>" +
        '<button class="btn btn-accent btn-sm" data-action="go" data-hash="#/quiz/run">Resume</button></div></div>'
      : "") +
    '<div class="card quiz-setup mt-2">' +
    '<div class="field"><label>Subject</label><select id="qs-subject">' +
    SUBJECTS.map((s) => '<option value="' + s.id + '">' + s.icon + " " + s.name + "</option>").join("") +
    "</select></div>" +
    '<div class="field"><label>Topic</label><select id="qs-topic">' +
    '<option value="all">All topics</option>' +
    defaultSubject.topics.map((t) => '<option value="' + t.id + '">' + t.name + "</option>").join("") +
    "</select></div>" +
    '<div class="field"><label>Number of questions</label><div class="option-grid" id="qs-count">' +
    [5, 10, 15, 20].map((n, i) => '<div class="count-chip' + (i === 0 ? " active" : "") + '" data-action="qs-set-count" data-value="' + n + '">' + n + "</div>").join("") +
    "</div></div>" +
    '<p class="muted small">Allow about 1 minute per question — the timer counts down automatically and the quiz auto-submits at 00:00.</p>' +
    '<div id="qs-err" class="small" style="color:var(--coral)"></div>' +
    '<button class="btn btn-primary btn-block mt-2" data-action="start-quiz">Start Quiz</button>' +
    "</div>"
  );
}

function quickStartQuiz(subjectId, topicId) {
  const pool = QUESTIONS.filter((q) => q.subjectId === subjectId && (!topicId || q.topicId === topicId));
  if (!pool.length) {
    showToast("No sample questions available for this selection yet.", "error");
    return;
  }
  startQuiz(subjectId, topicId || "all", Math.min(10, pool.length));
}

function startQuiz(subjectId, topicId, count) {
  const pool = QUESTIONS.filter((q) => q.subjectId === subjectId && (topicId === "all" || q.topicId === topicId));
  if (!pool.length) {
    showToast("No questions available for that selection.", "error");
    return false;
  }
  const shuffled = pool.slice().sort(() => Math.random() - 0.5);
  const selected = shuffled.slice(0, Math.min(count, shuffled.length));
  const durationSeconds = selected.length * 60;
  const quiz = {
    id: uid("quiz"),
    subjectId: subjectId,
    topicId: topicId,
    questionIds: selected.map((q) => q.id),
    current: 0,
    answers: {},
    startedAt: new Date().toISOString(),
    endTime: Date.now() + durationSeconds * 1000,
    durationSeconds: durationSeconds,
  };
  saveData(STORE_KEYS.QUIZ_IN_PROGRESS, quiz);
  navigateTo("#/quiz/run");
  return true;
}

/* ================= QUIZ ENGINE: RUNNING ================= */

function viewQuizRunning() {
  const quiz = loadData(STORE_KEYS.QUIZ_IN_PROGRESS);
  if (!quiz) {
    return (
      '<div class="empty-state"><div class="emoji">📝</div><h3>No quiz in progress</h3>' +
      '<p class="muted">Set up a new practice quiz to get started.</p>' +
      '<button class="btn btn-primary mt-2" data-action="go" data-hash="#/quiz/setup">Set up a quiz</button></div>'
    );
  }
  const qId = quiz.questionIds[quiz.current];
  const q = QUESTIONS.find((x) => x.id === qId);
  const letters = ["A", "B", "C", "D"];
  const selected = quiz.answers[qId];
  const remaining = Math.max(0, Math.round((quiz.endTime - Date.now()) / 1000));

  return (
    '<div class="quiz-header">' +
    '<button class="back-btn" data-action="quit-quiz">✕</button>' +
    '<span class="timer-pill' + (remaining <= 30 ? " low" : "") + '" id="quizTimer">' + formatTime(remaining) + "</span>" +
    "</div>" +
    '<div class="q-progress">Question ' + (quiz.current + 1) + " of " + quiz.questionIds.length + "</div>" +
    '<div class="progress-bar mt-0"><span style="width:' + (((quiz.current + 1) / quiz.questionIds.length) * 100) + '%"></span></div>' +
    '<div class="card question-card mt-2">' +
    '<div class="question-text">' + escapeHtml(q.question) + "</div>" +
    q.options.map((opt, i) => {
      const cls = "option-btn" + (selected === i ? " selected" : "");
      return (
        '<button class="' + cls + '" data-action="answer-question" data-index="' + i + '">' +
        '<span class="opt-letter">' + letters[i] + '</span><span>' + escapeHtml(opt) + "</span></button>"
      );
    }).join("") +
    "</div>" +
    '<div class="row between mt-2">' +
    '<button class="btn btn-ghost" data-action="quiz-prev" ' + (quiz.current === 0 ? "disabled" : "") + ">‹ Previous</button>" +
    (quiz.current === quiz.questionIds.length - 1
      ? '<button class="btn btn-primary" data-action="quiz-submit">Submit Quiz</button>'
      : '<button class="btn btn-primary" data-action="quiz-next">Next ›</button>') +
    "</div>" +
    '<h4 class="section-title mt-3">Jump to question</h4>' +
    '<div class="qnav-grid mt-1">' +
    quiz.questionIds.map((id, i) => {
      let cls = "qnav-dot";
      if (quiz.answers.hasOwnProperty(id)) cls += " answered";
      if (i === quiz.current) cls += " current";
      return '<button class="' + cls + '" data-action="quiz-jump" data-index="' + i + '">' + (i + 1) + "</button>";
    }).join("") +
    "</div>"
  );
}

function startQuizTimerLoop() {
  stopQuizTimerLoop();
  state.quizTimerId = setInterval(() => {
    const quiz = loadData(STORE_KEYS.QUIZ_IN_PROGRESS);
    if (!quiz) { stopQuizTimerLoop(); return; }
    const remaining = Math.max(0, Math.round((quiz.endTime - Date.now()) / 1000));
    const pill = document.getElementById("quizTimer");
    if (pill) {
      pill.textContent = formatTime(remaining);
      pill.classList.toggle("low", remaining <= 30);
    }
    if (remaining <= 0) {
      stopQuizTimerLoop();
      showToast("Time's up! Submitting your quiz…");
      submitQuiz(true);
    }
  }, 1000);
}
function stopQuizTimerLoop() {
  if (state.quizTimerId) { clearInterval(state.quizTimerId); state.quizTimerId = null; }
}

function answerQuestion(index) {
  const quiz = loadData(STORE_KEYS.QUIZ_IN_PROGRESS);
  if (!quiz) return;
  const qId = quiz.questionIds[quiz.current];
  quiz.answers[qId] = index;
  saveData(STORE_KEYS.QUIZ_IN_PROGRESS, quiz);
  render();
}

function quizStep(delta) {
  const quiz = loadData(STORE_KEYS.QUIZ_IN_PROGRESS);
  if (!quiz) return;
  const next = quiz.current + delta;
  if (next < 0 || next >= quiz.questionIds.length) return;
  quiz.current = next;
  saveData(STORE_KEYS.QUIZ_IN_PROGRESS, quiz);
  render();
}

function quizJump(index) {
  const quiz = loadData(STORE_KEYS.QUIZ_IN_PROGRESS);
  if (!quiz) return;
  quiz.current = index;
  saveData(STORE_KEYS.QUIZ_IN_PROGRESS, quiz);
  render();
}

function quitQuiz() {
  if (window.confirm("Leave this quiz? Your progress will be saved and you can resume later from the Quiz tab.")) {
    navigateTo("#/quiz/setup");
  }
}

function submitQuiz(auto) {
  const quiz = loadData(STORE_KEYS.QUIZ_IN_PROGRESS);
  if (!quiz) return;
  const unanswered = quiz.questionIds.length - Object.keys(quiz.answers).length;
  if (!auto && unanswered > 0) {
    if (!window.confirm(unanswered + " question(s) unanswered. Submit anyway?")) return;
  }

  let correct = 0;
  const detail = quiz.questionIds.map((id) => {
    const q = QUESTIONS.find((x) => x.id === id);
    const chosen = quiz.answers.hasOwnProperty(id) ? quiz.answers[id] : null;
    const isCorrect = chosen === q.answer;
    if (isCorrect) correct++;
    recordTopicProgress(q.topicId, isCorrect);
    return { questionId: id, chosen: chosen, correct: isCorrect };
  });

  const total = quiz.questionIds.length;
  const wrong = total - correct;
  const timeUsedSeconds = quiz.durationSeconds - Math.max(0, Math.round((quiz.endTime - Date.now()) / 1000));
  const result = {
    id: quiz.id,
    date: new Date().toISOString(),
    subjectId: quiz.subjectId,
    topicId: quiz.topicId,
    total: total,
    correct: correct,
    wrong: wrong,
    percentage: Math.round((correct / total) * 100),
    timeUsedSeconds: Math.max(0, timeUsedSeconds),
    detail: detail,
  };

  const history = loadData(STORE_KEYS.QUIZ_HISTORY) || [];
  history.unshift(result);
  saveData(STORE_KEYS.QUIZ_HISTORY, history);
  saveData(STORE_KEYS.QUIZ_IN_PROGRESS, null);
  logActivity("Completed a " + subjectById(quiz.subjectId).name + " quiz — scored " + result.percentage + "%");

  navigateTo("#/quiz/result");
}

/* ================= QUIZ ENGINE: RESULT ================= */

function viewQuizResult() {
  const history = loadData(STORE_KEYS.QUIZ_HISTORY) || [];
  const result = history[0];
  if (!result) {
    return (
      '<div class="empty-state"><div class="emoji">📊</div><h3>No result to show</h3>' +
      '<button class="btn btn-primary mt-2" data-action="go" data-hash="#/quiz/setup">Take a quiz</button></div>'
    );
  }
  const s = subjectById(result.subjectId);
  const letters = ["A", "B", "C", "D"];
  const ringColor = result.percentage >= 70 ? "var(--green)" : result.percentage >= 40 ? "var(--amber)" : "var(--coral)";

  return (
    '<div class="page-title-row"><h2>Quiz Result</h2></div>' +
    '<div class="card center">' +
    '<div class="result-ring-lg">' + svgRing(result.percentage, 150, ringColor, 12) +
    '<div class="ring-label"><span class="pct">' + result.percentage + '%</span><span class="small muted">' + result.correct + "/" + result.total + "</span></div></div>" +
    "<h3 class=\"mt-2\">" + s.name + (result.topicId !== "all" ? " · " + (topicById(result.subjectId, result.topicId) || {}).name : "") + "</h3>" +
    '<p class="muted small">' + formatDate(result.date, { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) + "</p>" +
    "</div>" +
    '<div class="grid grid-3 mt-2">' +
    '<div class="card stat-card"><div class="stat-value" style="color:var(--green)">' + result.correct + '</div><div class="stat-label">Correct</div></div>' +
    '<div class="card stat-card"><div class="stat-value" style="color:var(--coral)">' + result.wrong + '</div><div class="stat-label">Wrong</div></div>' +
    '<div class="card stat-card"><div class="stat-value">' + formatTime(result.timeUsedSeconds) + '</div><div class="stat-label">Time used</div></div>' +
    "</div>" +
    '<div class="row mt-2" style="gap:10px">' +
    '<button class="btn btn-ghost btn-block" data-action="go" data-hash="#/quiz/setup">New quiz</button>' +
    '<button class="btn btn-primary btn-block" data-action="go" data-hash="#/scores">View history</button>' +
    "</div>" +
    '<h3 class="section-title mt-3">Review answers</h3>' +
    '<div class="mt-1">' +
    result.detail.map((d) => {
      const q = QUESTIONS.find((x) => x.id === d.questionId);
      return (
        '<div class="review-item ' + (d.correct ? "correct" : "incorrect") + '">' +
        '<p style="font-weight:600">' + escapeHtml(q.question) + "</p>" +
        '<p class="small">Your answer: ' + (d.chosen === null ? "<i>Not answered</i>" : letters[d.chosen] + ". " + escapeHtml(q.options[d.chosen])) + "</p>" +
        (d.correct ? "" : '<p class="small" style="color:var(--green)">Correct answer: ' + letters[q.answer] + ". " + escapeHtml(q.options[q.answer]) + "</p>") +
        '<p class="small muted mt-0">' + escapeHtml(q.explanation) + "</p>" +
        "</div>"
      );
    }).join("") +
    "</div>"
  );
}

/* ================= VIEW: SCORE TRACKER ================= */

function viewScoreTracker() {
  const history = loadData(STORE_KEYS.QUIZ_HISTORY) || [];
  const recent = history.slice(0, 10).slice().reverse(); // chronological for the chart
  const maxBars = recent.length;

  return (
    '<div class="page-title-row"><h2>Score Tracker</h2></div>' +
    (history.length === 0
      ? '<div class="empty-state"><div class="emoji">📈</div><h3>No quizzes yet</h3><p class="muted">Complete a practice quiz to start tracking your scores.</p>' +
        '<button class="btn btn-primary mt-2" data-action="go" data-hash="#/quiz/setup">Take a quiz</button></div>'
      :
      '<div class="card">' +
      '<h4 class="section-title">Last ' + maxBars + ' quiz scores</h4>' +
      '<div class="row" style="align-items:flex-end;gap:6px;height:120px;margin-top:14px;overflow-x:auto">' +
      recent.map((r) => {
        const h = Math.max(4, Math.round((r.percentage / 100) * 100));
        const color = r.percentage >= 70 ? "var(--green)" : r.percentage >= 40 ? "var(--amber)" : "var(--coral)";
        return '<div style="flex:1;min-width:22px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%">' +
          '<div class="small" style="margin-bottom:3px">' + r.percentage + '%</div>' +
          '<div style="width:100%;height:' + h + 'px;background:' + color + ';border-radius:5px 5px 0 0"></div></div>';
      }).join("") +
      "</div>" +
      '<p class="muted small mt-2">' + (isImproving(history) ? "📈 Your recent scores are trending upward — keep it up!" : "Keep practicing consistently to build an upward trend.") + "</p>" +
      "</div>" +

      '<h3 class="section-title mt-3">Full history</h3>' +
      '<div class="stack mt-1">' +
      history.map((r) => {
        const s = subjectById(r.subjectId);
        return (
          '<div class="card">' +
          '<div class="row between"><b>' + s.icon + " " + s.name + "</b><span class=\"badge\" style=\"background:" + s.color + "22;color:" + s.color + '">' + r.percentage + "%</span></div>" +
          '<p class="muted small mt-0">' + formatDate(r.date, { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) + "</p>" +
          '<div class="row wrap small mt-1" style="gap:12px">' +
          "<span>✔ " + r.correct + " correct</span><span>✘ " + r.wrong + " wrong</span><span>" + r.total + " attempted</span><span>⏱ " + formatTime(r.timeUsedSeconds) + "</span>" +
          "</div></div>"
        );
      }).join("") +
      "</div>"
    )
  );
}

function isImproving(history) {
  if (history.length < 2) return false;
  const recent = history.slice(0, 3);
  const older = history.slice(3, 6);
  if (!older.length) return recent[0].percentage >= recent[recent.length - 1].percentage;
  const avgRecent = recent.reduce((a, b) => a + b.percentage, 0) / recent.length;
  const avgOlder = older.reduce((a, b) => a + b.percentage, 0) / older.length;
  return avgRecent >= avgOlder;
}

/* ================= VIEW: TIMETABLE ================= */

function timetableItemHtml(item) {
  const d = new Date(item.date + "T00:00:00");
  const day = isNaN(d.getTime()) ? "--" : d.getDate();
  const mon = isNaN(d.getTime()) ? "" : d.toLocaleDateString("en-GB", { month: "short" });
  const s = item.subjectId ? subjectById(item.subjectId) : null;
  return (
    '<div class="timetable-item' + (item.completed ? " completed" : "") + '">' +
    '<div class="tt-date-chip"><div class="day">' + day + '</div><div class="mon">' + mon + "</div></div>" +
    '<div style="flex:1">' +
    '<div class="tt-title" style="font-weight:600">' + escapeHtml(item.title) + "</div>" +
    '<div class="muted small">' + (s ? s.icon + " " + s.name + " · " : "") + (item.time || "") + "</div>" +
    (item.notes ? '<div class="small mt-0">' + escapeHtml(item.notes) + "</div>" : "") +
    "</div>" +
    '<div class="stack" style="gap:6px">' +
    '<button class="btn btn-sm ' + (item.completed ? "btn-ghost" : "btn-accent") + '" data-action="toggle-session" data-id="' + item.id + '">' + (item.completed ? "Undo" : "Done") + "</button>" +
    '<button class="btn btn-sm btn-danger" data-action="delete-session" data-id="' + item.id + '">Delete</button>' +
    "</div></div>"
  );
}

function viewTimetable() {
  const sessions = (loadData(STORE_KEYS.TIMETABLE) || []).slice().sort((a, b) => (a.date + (a.time || "")).localeCompare(b.date + (b.time || "")));
  return (
    '<div class="page-title-row row between" style="width:100%"><h2>Study Timetable</h2><button class="btn btn-accent btn-sm" data-action="open-session-form">+ Add</button></div>' +
    (sessions.length
      ? '<div class="stack mt-2">' + sessions.map((s) => timetableItemHtml(s)).join("") + "</div>"
      : '<div class="empty-state"><div class="emoji">🗓️</div><h3>No study sessions yet</h3><p class="muted">Plan your revision by adding a study session.</p>' +
        '<button class="btn btn-primary mt-2" data-action="open-session-form">Add your first session</button></div>')
  );
}

function sessionFormSheet(existing) {
  const subjOptions = SUBJECTS.map((s) =>
    '<option value="' + s.id + '"' + (existing && existing.subjectId === s.id ? " selected" : "") + ">" + s.icon + " " + s.name + "</option>"
  ).join("");
  return (
    '<div class="overlay" data-action="close-sheet" id="sheetOverlay">' +
    '<div class="sheet" data-stop-propagation="true">' +
    '<div class="sheet-handle"></div>' +
    "<h3>" + (existing ? "Edit" : "Add") + " study session</h3>" +
    '<form data-form="session" class="mt-2">' +
    '<input type="hidden" name="id" value="' + (existing ? existing.id : "") + '">' +
    '<div class="field"><label>Title</label><input name="title" type="text" placeholder="e.g. Revise Cell Structure" value="' + (existing ? escapeHtml(existing.title) : "") + '" required></div>' +
    '<div class="field"><label>Subject</label><select name="subjectId"><option value="">— No subject —</option>' + subjOptions + "</select></div>" +
    '<div class="field"><label>Date</label><input name="date" type="date" value="' + (existing ? existing.date : "") + '" required></div>' +
    '<div class="field"><label>Time</label><input name="time" type="time" value="' + (existing ? existing.time : "") + '"></div>' +
    '<div class="field"><label>Notes</label><textarea name="notes" rows="2" placeholder="Optional notes">' + (existing ? escapeHtml(existing.notes) : "") + "</textarea></div>" +
    '<div id="sessionErr" class="small" style="color:var(--coral)"></div>' +
    '<div class="row mt-1" style="gap:10px">' +
    '<button type="button" class="btn btn-ghost btn-block" data-action="close-sheet">Cancel</button>' +
    '<button type="submit" class="btn btn-primary btn-block">Save session</button>' +
    "</div></form></div></div>"
  );
}

/* ================= VIEW: PROGRESS ================= */

function viewProgress() {
  const stats = overallStats();
  const overallPct = stats.attempted ? Math.round((stats.correct / stats.attempted) * 100) : 0;
  return (
    '<div class="page-title-row"><h2>Study Progress</h2></div>' +
    '<div class="card center">' +
    '<div class="ring-wrap" style="width:110px;height:110px;margin:0 auto">' + svgRing(overallPct, 110, "var(--navy-800)", 10) +
    '<div class="ring-label" style="font-size:1.3rem">' + overallPct + "%</div></div>" +
    '<p class="muted small mt-1">Overall accuracy across all subjects</p>' +
    "</div>" +
    '<div class="grid grid-3 mt-2">' +
    '<div class="card stat-card"><div class="stat-value">' + stats.attempted + '</div><div class="stat-label">Attempted</div></div>' +
    '<div class="card stat-card"><div class="stat-value">' + stats.correct + '</div><div class="stat-label">Correct</div></div>' +
    '<div class="card stat-card"><div class="stat-value">' + stats.avgScore + '%</div><div class="stat-label">Quiz average</div></div>' +
    "</div>" +
    '<h3 class="section-title mt-3">By subject</h3>' +
    '<div class="stack mt-1">' +
    SUBJECTS.map((s) => {
      const pct = subjectProgressPct(s.id);
      const topicsCompleted = s.topics.filter((t) => getTopicProgress(t.id).attempted > 0).length;
      return (
        '<div class="card">' +
        '<div class="row between"><div class="row"><span class="subject-icon" style="width:36px;height:36px;font-size:1.1rem;background:' + s.color + '">' + s.icon + "</span><b>" + s.name + "</b></div><b>" + pct + "%</b></div>" +
        '<div class="progress-bar mt-1"><span style="width:' + pct + '%;background:' + s.color + '"></span></div>' +
        '<p class="muted small mt-1">' + topicsCompleted + " of " + s.topics.length + " topics started</p>" +
        "</div>"
      );
    }).join("") +
    "</div>"
  );
}

/* ================= VIEW: BOOKMARKS ================= */

function viewBookmarks() {
  const bookmarks = loadData(STORE_KEYS.BOOKMARKS) || DEFAULTS[STORE_KEYS.BOOKMARKS];
  const tab = state.bookmarkTab;
  const qItems = QUESTIONS.filter((q) => bookmarks.questions.includes(q.id));
  const mItems = MATERIALS.filter((m) => bookmarks.materials.includes(m.id));

  return (
    '<div class="page-title-row"><h2>Bookmarks</h2></div>' +
    '<div class="tab-bar">' +
    '<button class="tab-btn' + (tab === "questions" ? " active" : "") + '" data-action="bookmark-tab" data-value="questions">Questions (' + qItems.length + ")</button>" +
    '<button class="tab-btn' + (tab === "materials" ? " active" : "") + '" data-action="bookmark-tab" data-value="materials">Materials (' + mItems.length + ")</button>" +
    "</div>" +
    '<div class="stack mt-2">' +
    (tab === "questions"
      ? (qItems.length ? qItems.map((q) => questionAccordionHtml(q, true)).join("") : '<div class="empty-state"><div class="emoji">🔖</div><p>No bookmarked questions yet.</p></div>')
      : (mItems.length ? mItems.map((m) => materialItemHtml(m)).join("") : '<div class="empty-state"><div class="emoji">🔖</div><p>No bookmarked materials yet.</p></div>')
    ) +
    "</div>"
  );
}

/* ================= VIEW: SEARCH ================= */

function searchAll(term) {
  const t = term.trim().toLowerCase();
  if (!t) return { materials: [], questions: [], topics: [] };
  const materials = MATERIALS.filter((m) => (m.title + " " + m.explanation).toLowerCase().includes(t));
  const questions = QUESTIONS.filter((q) => q.question.toLowerCase().includes(t));
  const topics = [];
  SUBJECTS.forEach((s) => s.topics.forEach((tp) => { if (tp.name.toLowerCase().includes(t)) topics.push({ subjectId: s.id, topic: tp }); }));
  return { materials, questions, topics };
}

function viewSearch() {
  const term = state.searchTerm;
  const results = searchAll(term);
  const total = results.materials.length + results.questions.length + results.topics.length;
  return (
    '<div class="page-title-row"><h2>Search</h2></div>' +
    '<input id="globalSearchInput" type="search" placeholder="Search materials, topics, questions…" value="' + escapeHtml(term) + '">' +
    (term.trim() === ""
      ? '<div class="empty-state"><div class="emoji">🔎</div><p>Start typing to search across the whole app.</p></div>'
      : total === 0
      ? '<div class="empty-state"><div class="emoji">🙁</div><p>No results for "' + escapeHtml(term) + '".</p></div>'
      : '<div class="stack mt-2">' +
        results.topics.map((r) => '<div class="search-result" data-action="go" data-hash="#/subject/' + r.subjectId + "/topic/" + r.topic.id + '"><span class="type-badge">Topic</span><span>' + escapeHtml(r.topic.name) + "</span></div>").join("") +
        results.materials.map((m) => '<div class="search-result" data-action="go" data-hash="#/material/' + m.id + '"><span class="type-badge">Material</span><span>' + escapeHtml(m.title) + "</span></div>").join("") +
        results.questions.map((q) => '<div class="search-result" data-action="go" data-hash="#/questions"><span class="type-badge">Question</span><span>' + escapeHtml(q.question.slice(0, 60)) + "…</span></div>").join("") +
        "</div>"
    )
  );
}

/* ================= VIEW: ANNOUNCEMENTS ================= */

function viewAnnouncements() {
  const icons = { reminder: "⏰", exam: "🎓", study: "📘" };
  return (
    '<div class="page-title-row"><h2>Announcements</h2></div>' +
    '<div class="stack mt-1">' +
    ANNOUNCEMENTS.slice().sort((a, b) => b.date.localeCompare(a.date)).map((a) =>
      '<div class="card"><div class="row"><span style="font-size:1.3rem">' + (icons[a.type] || "📢") + '</span><div style="flex:1">' +
      '<div class="row between"><b>' + escapeHtml(a.title) + '</b></div>' +
      '<p class="small mt-0">' + escapeHtml(a.body) + "</p>" +
      '<p class="muted small mt-0">' + formatDate(a.date) + "</p></div></div></div>"
    ).join("") +
    "</div>"
  );
}

/* ================= VIEW: CALCULATORS ================= */

function viewCalculators() {
  const tab = state.calcTab;
  return (
    '<div class="page-title-row"><h2>Calculators</h2></div>' +
    '<div class="tab-bar">' +
    '<button class="tab-btn' + (tab === "basic" ? " active" : "") + '" data-action="calc-tab" data-value="basic">Basic</button>' +
    '<button class="tab-btn' + (tab === "percentage" ? " active" : "") + '" data-action="calc-tab" data-value="percentage">Percentage</button>' +
    '<button class="tab-btn' + (tab === "grade" ? " active" : "") + '" data-action="calc-tab" data-value="grade">Score / Grade</button>' +
    "</div>" +
    '<div class="mt-2">' +
    (tab === "basic" ? calcBasicHtml() : tab === "percentage" ? calcPercentageHtml() : calcGradeHtml()) +
    "</div>"
  );
}

function calcBasicHtml() {
  return (
    '<div class="card">' +
    '<div class="calc-display" id="calcDisplay">0</div>' +
    '<div class="calc-grid">' +
    ["C", "±", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "0", ".", "="].map((k) => {
      let cls = "calc-key";
      if (["÷", "×", "−", "+"].includes(k)) cls += " op";
      if (k === "=") cls += " eq";
      let span = "";
      if (k === "0") span = 'style="grid-column: span 2"';
      return '<button class="' + cls + '" ' + span + ' data-action="calc-key" data-key="' + k + '">' + k + "</button>";
    }).join("") +
    "</div></div>"
  );
}

function renderCalcDisplay() {
  const el = document.getElementById("calcDisplay");
  if (el) el.textContent = state.calcExpr || "0";
}

function calcKeyPress(key) {
  if (key === "C") { state.calcExpr = ""; renderCalcDisplay(); return; }
  if (key === "±") {
    if (state.calcExpr && !isNaN(state.calcExpr[state.calcExpr.length - 1])) {
      state.calcExpr = state.calcExpr.startsWith("-") ? state.calcExpr.slice(1) : "-" + state.calcExpr;
    }
    renderCalcDisplay();
    return;
  }
  if (key === "=") {
    try {
      let expr = state.calcExpr.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/%/g, "/100");
      if (!/^[0-9+\-*/.() ]+$/.test(expr) || expr.trim() === "") throw new Error("invalid");
      // eslint-disable-next-line no-new-func
      const result = Function('"use strict";return (' + expr + ")")();
      if (typeof result !== "number" || !isFinite(result)) throw new Error("invalid result");
      state.calcExpr = String(Math.round(result * 1e8) / 1e8);
    } catch (e) {
      showToast("Invalid calculation", "error");
      state.calcExpr = "";
    }
    renderCalcDisplay();
    return;
  }
  const opMap = { "÷": "÷", "×": "×", "−": "−", "+": "+", "%": "%" };
  if (opMap[key]) {
    if (state.calcExpr === "" && key !== "−") return;
    state.calcExpr += key;
  } else {
    state.calcExpr += key;
  }
  renderCalcDisplay();
}

function calcPercentageHtml() {
  return (
    '<div class="card">' +
    '<h4 class="section-title">What is X% of Y?</h4>' +
    '<div class="row mt-1" style="gap:8px">' +
    '<input id="pc-x" type="number" placeholder="X (%)" inputmode="decimal">' +
    '<input id="pc-y" type="number" placeholder="Y" inputmode="decimal">' +
    "</div>" +
    '<button class="btn btn-primary btn-block mt-2" data-action="calc-pct-of">Calculate</button>' +
    '<p id="pc-result" class="mt-1" style="font-weight:700"></p>' +
    "</div>" +
    '<div class="card mt-2">' +
    '<h4 class="section-title">X is what % of Y?</h4>' +
    '<div class="row mt-1" style="gap:8px">' +
    '<input id="pc2-x" type="number" placeholder="X" inputmode="decimal">' +
    '<input id="pc2-y" type="number" placeholder="Y" inputmode="decimal">' +
    "</div>" +
    '<button class="btn btn-primary btn-block mt-2" data-action="calc-pct-is">Calculate</button>' +
    '<p id="pc2-result" class="mt-1" style="font-weight:700"></p>' +
    "</div>"
  );
}

function calcPctOf() {
  const x = parseFloat($("#pc-x").value);
  const y = parseFloat($("#pc-y").value);
  const out = $("#pc-result");
  if (isNaN(x) || isNaN(y)) { out.textContent = "Please enter valid numbers in both fields."; out.style.color = "var(--coral)"; return; }
  out.style.color = "var(--text)";
  out.textContent = x + "% of " + y + " = " + (Math.round((x / 100) * y * 100) / 100);
}
function calcPctIs() {
  const x = parseFloat($("#pc2-x").value);
  const y = parseFloat($("#pc2-y").value);
  const out = $("#pc2-result");
  if (isNaN(x) || isNaN(y) || y === 0) { out.textContent = "Please enter valid numbers (Y cannot be 0)."; out.style.color = "var(--coral)"; return; }
  out.style.color = "var(--text)";
  out.textContent = x + " is " + (Math.round((x / y) * 10000) / 100) + "% of " + y;
}

function calcGradeHtml() {
  return (
    '<div class="card">' +
    '<h4 class="section-title">Score / Grade calculator</h4>' +
    '<p class="muted small">Enter your score and the total obtainable marks to get a percentage and a simple indicative grade.</p>' +
    '<div class="field mt-1"><label>Score obtained</label><input id="gr-score" type="number" inputmode="decimal" placeholder="e.g. 42"></div>' +
    '<div class="field"><label>Total obtainable</label><input id="gr-total" type="number" inputmode="decimal" placeholder="e.g. 50"></div>' +
    '<button class="btn btn-primary btn-block" data-action="calc-grade">Calculate</button>' +
    '<div id="gr-result" class="mt-2"></div>' +
    "</div>"
  );
}

function calcGrade() {
  const score = parseFloat($("#gr-score").value);
  const total = parseFloat($("#gr-total").value);
  const out = $("#gr-result");
  if (isNaN(score) || isNaN(total) || total <= 0 || score < 0) {
    out.innerHTML = '<p style="color:var(--coral)">Please enter a valid score and total (total must be greater than 0).</p>';
    return;
  }
  if (score > total) {
    out.innerHTML = '<p style="color:var(--coral)">Score cannot be greater than the total obtainable.</p>';
    return;
  }
  const pct = Math.round((score / total) * 10000) / 100;
  let grade, color;
  if (pct >= 70) { grade = "A — Excellent"; color = "var(--green)"; }
  else if (pct >= 60) { grade = "B — Very Good"; color = "var(--green)"; }
  else if (pct >= 50) { grade = "C — Good"; color = "var(--amber-dark)"; }
  else if (pct >= 45) { grade = "D — Fair"; color = "var(--amber-dark)"; }
  else if (pct >= 40) { grade = "E — Pass"; color = "var(--coral)"; }
  else { grade = "F — Fail"; color = "var(--coral)"; }
  out.innerHTML = '<p style="font-size:1.6rem;font-weight:700;color:' + color + '">' + pct + '%</p><p style="font-weight:600">' + grade + '</p><p class="muted small">This is a simple indicative guide only, not an official IJMB grading scale.</p>';
}

/* ================= VIEW: SETTINGS ================= */

function viewSettings() {
  const theme = getTheme();
  return (
    '<div class="page-title-row"><h2>Settings</h2></div>' +
    '<div class="card">' +
    '<div class="settings-row"><div><b>Dark mode</b><div class="muted small">Easier on the eyes at night</div></div>' +
    '<label class="switch"><input type="checkbox" id="darkModeToggle" ' + (theme === "dark" ? "checked" : "") + '><span class="track"></span></label></div>' +
    "</div>" +
    '<h4 class="section-title mt-3">Data</h4>' +
    '<div class="card mt-1">' +
    '<div class="settings-row"><div><b>Export progress summary</b><div class="muted small">See a quick text summary of your stats</div></div>' +
    '<button class="btn btn-ghost btn-sm" data-action="export-summary">View</button></div>' +
    '<div class="settings-row"><div><b>Clear quiz history</b><div class="muted small">Removes saved scores only</div></div>' +
    '<button class="btn btn-danger btn-sm" data-action="clear-history">Clear</button></div>' +
    '<div class="settings-row"><div><b>Reset all app data</b><div class="muted small">Profile, scores, bookmarks, timetable — this device only</div></div>' +
    '<button class="btn btn-danger btn-sm" data-action="reset-all">Reset</button></div>' +
    "</div>" +
    '<h4 class="section-title mt-3">About</h4>' +
    '<div class="card mt-1"><p class="small">IJMB Student Hub is a personal study companion for IJMB examination preparation. All data is stored only on this device using your browser\'s local storage — nothing is uploaded anywhere in this version.</p></div>'
  );
}

function viewMore() {
  const items = SIDEBAR_ITEMS.filter((i) => !NAV_ITEMS.some((n) => n.hash === i.hash) || i.hash === "#/more");
  return (
    '<div class="page-title-row"><h2>More</h2></div>' +
    '<div class="grid grid-3 mt-1">' +
    items.map((i) => '<button class="quick-btn" data-action="go" data-hash="' + i.hash + '"><span class="qb-icon">' + i.icon + "</span>" + i.label + "</button>").join("") +
    "</div>"
  );
}

function viewNotFound() {
  return (
    '<div class="empty-state"><div class="emoji">🧭</div><h3>Page not found</h3>' +
    '<button class="btn btn-primary mt-2" data-action="go" data-hash="#/dashboard">Back to Dashboard</button></div>'
  );
}

/* ================= ACTION HANDLERS ================= */
/* Every clickable data-action in the templates above maps to a
   function here. Centralising it means templates stay simple
   strings and behaviour lives in one place. */

const ACTIONS = {
  "go": (ds) => navigateTo(ds.hash),
  "toggle-theme": () => toggleTheme(),

  "quiz-quick-start": (ds) => quickStartQuiz(ds.subject, ds.topic),
  "qs-set-count": (ds, el) => {
    $all("#qs-count .count-chip").forEach((c) => c.classList.remove("active"));
    el.classList.add("active");
  },
  "qf-difficulty": (ds, el) => {
    state.questionFilters.difficulty = ds.value;
    render();
  },
  "start-quiz": () => {
    const subject = $("#qs-subject").value;
    const topic = $("#qs-topic") ? $("#qs-topic").value : "all";
    const activeChip = $("#qs-count .count-chip.active");
    const count = activeChip ? parseInt(activeChip.dataset.value, 10) : 10;
    const err = $("#qs-err");
    const pool = QUESTIONS.filter((q) => q.subjectId === subject && (topic === "all" || q.topicId === topic));
    if (!pool.length) {
      if (err) err.textContent = "No sample questions available for this selection yet. Try 'All topics' or another subject.";
      return;
    }
    startQuiz(subject, topic, count);
  },
  "answer-question": (ds) => answerQuestion(parseInt(ds.index, 10)),
  "quiz-prev": () => quizStep(-1),
  "quiz-next": () => quizStep(1),
  "quiz-jump": (ds) => quizJump(parseInt(ds.index, 10)),
  "quiz-submit": () => submitQuiz(false),
  "quit-quiz": () => quitQuiz(),

  "toggle-bookmark-question": (ds) => toggleBookmark("questions", ds.id),
  "toggle-bookmark-material": (ds) => toggleBookmark("materials", ds.id),
  "bookmark-tab": (ds) => { state.bookmarkTab = ds.value; render(); },

  "open-session-form": () => openSessionSheet(),
  "close-sheet": () => closeSheet(),
  "toggle-session": (ds) => toggleSessionCompleted(ds.id),
  "delete-session": (ds) => deleteSession(ds.id),
  "edit-session": (ds) => openSessionSheet(ds.id),

  "calc-tab": (ds) => { state.calcTab = ds.value; state.calcExpr = ""; render(); },
  "calc-key": (ds) => calcKeyPress(ds.key),
  "calc-pct-of": () => calcPctOf(),
  "calc-pct-is": () => calcPctIs(),
  "calc-grade": () => calcGrade(),

  "export-summary": () => exportSummary(),
  "clear-history": () => clearHistory(),
  "reset-all": () => resetAllData(),
};

function toggleBookmark(kind, id) {
  const bookmarks = loadData(STORE_KEYS.BOOKMARKS) || DEFAULTS[STORE_KEYS.BOOKMARKS];
  const list = bookmarks[kind];
  const idx = list.indexOf(id);
  if (idx >= 0) { list.splice(idx, 1); showToast("Removed bookmark"); }
  else { list.push(id); showToast("Bookmarked!", "success"); }
  saveData(STORE_KEYS.BOOKMARKS, bookmarks);
  render();
}

function openSessionSheet(existingId) {
  const sessions = loadData(STORE_KEYS.TIMETABLE) || [];
  const existing = existingId ? sessions.find((s) => s.id === existingId) : null;
  let container = document.getElementById("sheetContainer");
  if (!container) {
    container = document.createElement("div");
    container.id = "sheetContainer";
    document.body.appendChild(container);
  }
  container.innerHTML = sessionFormSheet(existing);
}
function closeSheet() {
  const container = document.getElementById("sheetContainer");
  if (container) container.innerHTML = "";
}
function toggleSessionCompleted(id) {
  const sessions = loadData(STORE_KEYS.TIMETABLE) || [];
  const s = sessions.find((x) => x.id === id);
  if (!s) return;
  s.completed = !s.completed;
  saveData(STORE_KEYS.TIMETABLE, sessions);
  if (s.completed) logActivity("Marked study session '" + s.title + "' as completed");
  render();
}
function deleteSession(id) {
  if (!window.confirm("Delete this study session?")) return;
  const sessions = (loadData(STORE_KEYS.TIMETABLE) || []).filter((s) => s.id !== id);
  saveData(STORE_KEYS.TIMETABLE, sessions);
  showToast("Session deleted");
  render();
}

function exportSummary() {
  const stats = overallStats();
  const p = loadData(STORE_KEYS.PROFILE) || {};
  const msg = (p.name ? p.name + "'s" : "Your") + " IJMB Student Hub summary:\n" +
    stats.attempted + " questions attempted, " + stats.correct + " correct, " +
    stats.avgScore + "% average across " + stats.quizCount + " quizzes.";
  window.alert(msg);
}
function clearHistory() {
  if (!window.confirm("Clear all saved quiz scores? This cannot be undone.")) return;
  saveData(STORE_KEYS.QUIZ_HISTORY, []);
  showToast("Quiz history cleared");
  render();
}
function resetAllData() {
  if (!window.confirm("Reset ALL app data on this device? Profile, scores, bookmarks and timetable will be permanently removed.")) return;
  Object.values(STORE_KEYS).forEach((k) => clearData(k));
  applyTheme("light");
  showToast("All data has been reset");
  navigateTo("#/dashboard");
}

/* ================= FORM HANDLERS ================= */

function handleProfileSubmit(form) {
  const name = form.elements["name"].value.trim();
  const err = $("#profileErr");
  if (!name) {
    if (err) err.textContent = "Please enter your name.";
    return;
  }
  if (err) err.textContent = "";
  const subjects = $all('input[name="subjects"]:checked', form).map((cb) => cb.value);
  const profile = {
    name: name,
    email: form.elements["email"].value.trim(),
    institution: form.elements["institution"].value.trim(),
    programme: form.elements["programme"].value.trim(),
    subjects: subjects,
  };
  saveData(STORE_KEYS.PROFILE, profile);
  logActivity("Updated profile details");
  showToast("Profile saved", "success");
  render();
}

function handleSessionSubmit(form) {
  const title = form.elements["title"].value.trim();
  const date = form.elements["date"].value;
  const err = $("#sessionErr");
  if (!title || !date) {
    if (err) err.textContent = "Please provide at least a title and a date.";
    return;
  }
  if (err) err.textContent = "";
  const id = form.elements["id"].value;
  const sessions = loadData(STORE_KEYS.TIMETABLE) || [];
  const data = {
    id: id || uid("sess"),
    title: title,
    subjectId: form.elements["subjectId"].value || null,
    date: date,
    time: form.elements["time"].value,
    notes: form.elements["notes"].value.trim(),
    completed: false,
  };
  if (id) {
    const idx = sessions.findIndex((s) => s.id === id);
    if (idx >= 0) { data.completed = sessions[idx].completed; sessions[idx] = data; }
  } else {
    sessions.push(data);
    logActivity("Added a study session: " + title);
  }
  saveData(STORE_KEYS.TIMETABLE, sessions);
  closeSheet();
  showToast("Study session saved", "success");
  render();
}

/* ================= GLOBAL EVENT DELEGATION ================= */

function initGlobalListeners() {
  document.addEventListener("click", function (e) {
    const el = e.target.closest("[data-action]");
    if (!el) return;
    const action = el.dataset.action;
    // Special case: the sheet overlay only closes when the backdrop itself
    // (not the sheet content) is clicked.
    if (action === "close-sheet" && el.id === "sheetOverlay" && e.target.id !== "sheetOverlay") return;
    const handler = ACTIONS[action];
    if (handler) handler(el.dataset, el);
  });

  document.addEventListener("submit", function (e) {
    const form = e.target.closest("form[data-form]");
    if (!form) return;
    e.preventDefault();
    const kind = form.dataset.form;
    if (kind === "profile") handleProfileSubmit(form);
    if (kind === "session") handleSessionSubmit(form);
  });

  document.addEventListener("change", function (e) {
    if (e.target.id === "qs-subject") {
      const topicSelect = $("#qs-topic");
      const subj = subjectById(e.target.value);
      if (topicSelect && subj) {
        topicSelect.innerHTML = '<option value="all">All topics</option>' +
          subj.topics.map((t) => '<option value="' + t.id + '">' + t.name + "</option>").join("");
      }
    }
    if (e.target.id === "qf-subject") {
      state.questionFilters.subject = e.target.value;
      state.questionFilters.topic = "all";
      render();
    }
    if (e.target.id === "qf-topic") {
      state.questionFilters.topic = e.target.value;
      render();
    }
    if (e.target.id === "darkModeToggle") {
      applyTheme(e.target.checked ? "dark" : "light");
    }
    if (e.target.name === "subjects" && e.target.closest('form[data-form="profile"]')) {
      e.target.closest("label").classList.toggle("active", e.target.checked);
    }
  });

  document.addEventListener("input", function (e) {
    if (e.target.id === "globalSearchInput") {
      state.searchTerm = e.target.value;
      // Re-render just the results without losing input focus by
      // rendering then restoring focus + cursor position.
      const cursor = e.target.selectionStart;
      render();
      const input = $("#globalSearchInput");
      if (input) {
        input.focus();
        input.setSelectionRange(cursor, cursor);
      }
    }
  });

  window.addEventListener("hashchange", render);
}

/* ================= INIT ================= */

function init() {
  applyTheme(getTheme());
  buildShell();
  initGlobalListeners();
  render();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
